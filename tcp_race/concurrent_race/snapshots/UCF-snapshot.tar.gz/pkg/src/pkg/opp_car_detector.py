import re
import yaml
import math
from typing import Union
import numpy as np
from numba import njit, jit
# import matplotlib.pyplot as plt

# shapely.speedups.disable()


class OppCarDetector():
    def __init__(self, map_path, threshold=0.5):
        self.map_path = map_path
        self.threshold = threshold
        self.outer_path = np.array(
            RoutePath(map_path,
                      True,
                      map_res=0.08534,
                      path_name='outer_border',
                      close_loop=False).points)
        self.inner_path = np.array(
            RoutePath(map_path,
                      True,
                      map_res=0.08534,
                      path_name='inner_border',
                      close_loop=False).points)

    def get_obstacle_points(self, car_pos, ranges):
        car_pos = np.asarray(car_pos)
        points = np.asarray(scan_to_points(car_pos, ranges))
        obs_points = filter_obstacle_points(points, self.threshold,
                                            self.inner_path, self.outer_path)
        return obs_points

    def get_obstacle(self, car_pos, ranges):
        obs_points = np.asarray(self.get_obstacle_points(car_pos, ranges))
        if len(obs_points) > 0:
            avg_x, avg_y = np.mean(obs_points[:, 0]), np.mean(obs_points[:, 1])
            return avg_x, avg_y
        else:
            return None


@njit(cache=True)
def filter_obstacle_points(points, threshold, inner_path, outer_path):
    obs_points = []
    for point in points:
        inner_distances = np.sqrt(np.sum((point - inner_path)**2, 1))
        outer_distances = np.sqrt(np.sum((point - outer_path)**2, 1))
        if (inner_distances.min() > threshold
                and outer_distances.min() > threshold):
            obs_points.append(point)
    return obs_points


@njit(cache=True)
def scan_to_points(car_pos, ranges):
    points = []
    for i in range(0, len(ranges), 10):
        dist = ranges[i]
        if dist > 29:
            continue
        point = get_point_of_scan(dist, i, car_pos)
        points.append(point)
    return points


@njit(cache=True)
def get_point_of_scan(dist, index, car_pos):
    point = [
        dist * np.cos(lidar_index_to_radians(index) + car_pos[2]) + car_pos[0],
        dist * np.sin(lidar_index_to_radians(index) + car_pos[2]) + car_pos[1]
    ]
    return point


@njit(cache=True)
def lidar_index_to_degrees(index):
    return (index / 4.0) - 135


@njit(cache=True)
def lidar_index_to_radians(index):
    return np.radians(lidar_index_to_degrees(index))


class RoutePath:
    def __init__(self,
                 location: Union[str, list] = None,
                 format_path: bool = True,
                 map_res: float = None,
                 map_size=None,
                 map_start=None,
                 close_loop=True,
                 path_name='coords'):
        self.path_name = path_name
        self.close_loop = close_loop
        if type(location) == str:
            with open(location, 'r') as stream:
                input_file = yaml.load(stream)
            # print(input_file)
            self.points = load_data(input_file, self.close_loop,
                                    self.path_name)
            self.points.reverse()
            if not map_size:
                map_size = input_file['map_size']
            if not map_start:
                map_start = input_file['map_start']
        else:
            self.points = location
        self.start_pos = self.points[0]
        if (len(self.points) >= 2):
            self.start_yaw = get_yaw(self.points[0], self.points[1])
        self.close_loop = close_loop
        if format_path:
            self.points = scale_path(self.points, input_file['g'],
                                     input_file['canvas_size'], map_res,
                                     map_size, map_start)


def scale_path(points, g, canvas, map_res, map_size, map_start):
    for i in points:
        i[0] -= g[0]  # g translate
        i[1] -= g[1]
        # (map yaml resolution) * (map image size / inkscape canvas size)
        i[0] *= map_res * (map_size[0] / canvas[0])
        i[1] *= -map_res * (map_size[1] / canvas[1])
        i[0] += map_start[0]  # yaml start position
        i[1] += map_start[1] + map_size[1] * map_res  # yaml start + offset
    return points


def get_yaw(p1, p2):
    tgt_angle = math.atan2((-p2[0] + p1[0]), (-p2[1] + p1[1]))
    tgt_angle = (tgt_angle + math.pi * 2) % (math.pi * 2)
    if tgt_angle > math.pi:
        tgt_angle -= math.pi * 2
    return tgt_angle + math.pi / 2


def load_data(data, close_path, path_name):
    path_contents = data[path_name]
    # print(path_contents)
    path_contents = re.split(",| ", path_contents)[::-1]
    points = []
    for i in range(0, len(path_contents), 2):
        points.append([float(path_contents.pop()), float(path_contents.pop())])

    for i, _ in enumerate(points):
        if i == 0:
            continue
        points[i][0] += points[i - 1][0]
        points[i][1] += points[i - 1][1]
    if close_path:
        points.append([points[0][0], points[0][1]])
    return points
