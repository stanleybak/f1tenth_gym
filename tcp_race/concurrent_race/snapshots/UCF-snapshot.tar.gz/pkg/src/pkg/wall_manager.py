import numpy as np
from numba import njit, prange
from numba.typed import List
# 7 for skrik.pgm
# track_width = 4  # berlin
track_width = 6  # skirk
# 0.2 for high-viz debug
# car_behind_distance = 1
car_behind_distance = 0

# from original code

scan_width = 270.0
segment_width = 5  # degrees
# set_overlap = 1

max_walls = 4

# for raycasting methods that use a line segment, this is a line length
radar_range = 10.0

# right now, a wall is a half circle with the origin car_behind_distance behind the car
# radius is track_width/2
# but this could change to a arc with the chord length being the width of the track
# /shrug


class WallManager(object):
    def __init__(self):
        self.lines = List()
        print("wall manager init")
        # self.add_wall((0.18620185849810345, -0.04234416303427379, 0), 0)
        self.add_wall((0, 0, 0), 999)

    def add_wall(self,
                 location,
                 current_time,
                 radius=track_width / 2,
                 x_offset=0,
                 y_offset=0):
        """
        location: car location\\
        angle: forward direction of the car
        """
        angle = location[2] % (2 * np.pi)
        # override radius
        # radius = 7
        radius = min(radius, track_width / 2)
        # this could be a class or named tuple
        y_offset -= car_behind_distance
        y_offset -= radius / 2
        point = [
            location[0] - x_offset * np.sin(angle) - y_offset * np.cos(angle),
            location[1] + x_offset * np.cos(angle) - y_offset * np.sin(angle)
        ]
        wall = [
            float(point[0]),  # 0 
            float(point[1]),  # 1
            float((angle + np.pi) % (2 * np.pi)),  # 2
            float(current_time),  # 3
            float(radius),  # 4
        ]
        typed_list = List()
        [typed_list.append(x) for x in wall]
        # print(location, wall)
        self.lines.append(typed_list)
        # arc radius is track_width / 2
        # radius = track_width / 2

        if (len(self.lines) > max_walls):
            # could this be more efficient?
            self.lines = self.lines[1:]

    def filter_lidar(self, location, lidar_data, custom_data=None):
        """combines original lidar data with placed walls
        returns distances from original lidar data
        """
        # print("there are ", len(self.lines), " walls")
        if custom_data is None:
            distances = lidar_data.ranges
        else:
            distances = custom_data
        if (len(self.lines) <= 0):
            return distances
        # new_ranges = np.copy(distances)
        new_ranges = np.array(distances)
        # car_location = (location[0], location[1])
        # this is inefficient
        samples_per_degree = float(len(new_ranges)) / scan_width
        samples_per_segment = int(samples_per_degree * segment_width)
        typed_location = List()
        [typed_location.append(x) for x in location]
        typed_lines = List()
        [typed_lines.append(x) for x in self.lines]
        cast_rays(new_ranges, samples_per_segment, typed_location, location,
                  typed_lines)

        return new_ranges

    def remove_expired_walls(self, steps, wall_lifespan):
        self.lines = [
            line for line in self.lines if (steps - line[3] < wall_lifespan)
        ]


@njit
def angle_from_index(i, data):
    """ Returns the angle, in degrees, corresponding to index i in the
    LIDAR samples. """
    samples_per_degree = float(len(data)) / scan_width
    min_angle = -(scan_width / 2.0)
    return min_angle + (float(i) / samples_per_degree)


@njit
def cast_rays(new_ranges, samples_per_segment, typed_location, location,
              typed_lines):
    for segment in range(len(new_ranges) / (samples_per_segment)):
        # get the index of the middle position
        mid_index = int(samples_per_segment * segment +
                        samples_per_segment / 2.0)
        angle = np.radians(angle_from_index(mid_index, new_ranges))

        ray = [
            typed_location[0], typed_location[1],
            (angle + location[2]) % (2 * np.pi)
        ]
        typed_ray = List()
        [typed_ray.append(x) for x in ray]
        # print(type(typed_ray), type(typed_location), type(self.lines))
        dist = cast_ray(typed_ray, typed_location, typed_lines)
        if (dist is not None and dist < new_ranges[mid_index]):
            # write the new value
            # potential bug: could result in some values being higher
            new_ranges[mid_index - (samples_per_segment / 2):mid_index +
                       (samples_per_segment / 2)] = dist


@njit
def cast_ray(ray, location, lines):
    result = None
    for seg in range(len(lines)):
        intersection = get_intersection(ray, lines[seg])
        if intersection is None or len(intersection) <= 0:
            continue
        for point in intersection:
            dist = distance(location, point)
            if result is None or dist < result:
                result = dist
    return result


@njit
def get_intersection(ray, wall):
    x1 = ray[0]
    y1 = ray[1]
    angle = ray[2]
    x2 = x1 + np.cos(angle)
    y2 = y1 + np.sin(angle)
    # eq of line: ax + by + c = 0
    a = y2 - y1  # just in case
    b = x1 - x2
    c = x2 * y1 - x1 * y2
    # for arc
    r = wall[4]
    arc_start = (wall[2] - np.radians(90 - 15)) % (2 * np.pi)
    arc_end = (wall[2] + np.radians(90 - 15)) % (2 * np.pi)
    # print(arc_start, arc_end)
    # arc_start = np.radians(0)
    # arc_end = np.radians(359)

    points = List()

    t_1 = np.arctan2(b, a) + np.arccos(-(a * wall[0] + b * wall[1] + c) /
                                       (r * np.sqrt(a**2.0 + b**2.0)))
    t_1 = t_1 % (2 * np.pi)
    if (not np.isnan(t_1)) and anglebetween(t_1, arc_start, arc_end):
        t_1 = t_1 % (2 * np.pi)
        point = (float(r * np.cos(t_1) + wall[0]),
                 float(r * np.sin(t_1) + wall[1]))
        # make sure it's on the right side of the line
        if (b < 0 and (x1 - point[0]) < 0) or (b > 0 and (x1 - point[0]) > 0):
            points.append(point)

    t_2 = np.arctan2(b, a) - np.arccos(-(a * wall[0] + b * wall[1] + c) /
                                       (r * np.sqrt(a**2 + b**2)))
    t_2 = t_2 % (2 * np.pi)
    if (not np.isnan(t_2)) and anglebetween(t_2, arc_start, arc_end):
        t_2 = t_2 % (2 * np.pi)
        point = (float(r * np.cos(t_2) + wall[0]),
                 float(r * np.sin(t_2) + wall[1]))
        # make sure it's on the right side of the line
        if (b < 0 and (x1 - point[0]) < 0) or (b > 0 and (x1 - point[0]) > 0):
            points.append(point)
    if (len(points) > 0):
        return points
    else:
        return None


@njit
def distance(p1, p2):
    return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)


#https://stackoverflow.com/questions/11406189/determine-if-angle-lies-between-2-other-angles
@njit
def anglebetween(angle, start, end):
    rAngle = ((end - start) % (2 * np.pi) + (2 * np.pi)) % (2 * np.pi)
    if rAngle >= np.pi:
        tmp = start
        start = end
        end = tmp
    if start <= end:
        return angle >= start and angle <= end
    else:
        return angle >= start or angle <= end


# https://stackoverflow.com/a/34374437
def rotate(origin, point, angle):
    """
    Rotate a point counterclockwise by a given angle around a given origin.

    The angle should be given in radians.
    """
    ox, oy = origin
    px, py = point

    qx = ox + np.cos(angle) * (px - ox) - np.sin(angle) * (py - oy)
    qy = oy + np.sin(angle) * (px - ox) + np.cos(angle) * (py - oy)
    return qx, qy


# class Wall:
#     def __init__(self, center, angle, creation_time):
#         self.creation_time = creation_time
#         self.center = center
#         self.angle = angle
