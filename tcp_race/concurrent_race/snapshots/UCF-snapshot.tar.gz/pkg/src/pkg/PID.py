class PID:
    def __init__(self, kP, kI, kD):
        self.kP = kP
        self.kI = kI
        self.kD = kD
        # self.isteps = 100
        self.error = 0
        self.prevI = 0

    def step(self, target, current):
        error = target - current
        # print('error:', error)
        i = self.prevI + error * 1.0
        d = (error - self.error) / 1.0
        result = self.kP * error + self.kI * i + self.kD * d
        self.error = error
        self.prevI = i
        return result
