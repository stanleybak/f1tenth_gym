import numpy as np
import math

class VaNNewDrive():

    def select_velocity(self, angle):
        if abs(angle) <= 5 * math.pi / 180:
            velocity = 7.0
        elif abs(angle) <= 10 * math.pi / 180:
            velocity = 7.0
        elif abs(angle) <= 15 * math.pi / 180:
            velocity = 7.0
        elif abs(angle) <= 20 * math.pi / 180:
            velocity = 6.0
        else:
            velocity = 7.0
        return velocity

    def findangle(self, data):

        lid = []
        maxindex = 450
        i = 0
        x = 0
        readingold = 0
        gs = 0
        lgs = 0
        reading = 0

        while i < len(data):
            if (i <= 300) or (i >= 780):
                x = 0
                reading = 0
            elif data[i] <= 3.9:
                x = 0
                reading = 0
            else:
                reading += data[i] - 0.005 * abs(450 - i)
                x += 1
                if x > 10 and reading / x**0.3 > readingold:
                    readingold = reading / x**0.3
                    maxindex = i - x / 2
            i += 1
       
        return maxindex

    def process_observation(self, ranges=None, ego_odom=None):


    
        anglefound = self.findangle(ranges)

        angle_to_dist = (135 - anglefound / 4)

        pid_angle = -1 * angle_to_dist  

        
        if (angle_to_dist > 40) or (angle_to_dist < -40):
            pid_angle = np.clip(pid_angle, -0.4, 0.4)
        else:
            pid_angle /= 100
       
        steering_angle = pid_angle 

        

        return self.select_velocity(steering_angle), steering_angle
